package com.example.novel;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;


public class Menu_Adapter extends RecyclerView.Adapter<Menu_Adapter.MenuViewHolder>{
    private Context context;
    private ArrayList<menu> menuv;

    public Menu_Adapter(Context mcontext, ArrayList<menu> menunovel){
        context= mcontext;
        menuv= menunovel;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_menu,parent, false);

        return new MenuViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
            menu menubaru= menuv.get(position);
            String Gambarbaru = menubaru.getGambar();
            String Harga= menubaru.getHarga();
            String deskripsi= menubaru.getDeskripsi();
            String Nama= menubaru.getNama();

            holder.tvNamadata.setText(Nama);
            holder.tvhargadata.setText(Harga);
            holder.tvdeskripsi.setText(deskripsi);
        Glide
                .with(context)
                .load(Gambarbaru)
                .centerCrop()
                .into(holder.imdata);
    }

    @Override
    public int getItemCount() {
        return menuv.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvhargadata;
        public TextView tvNamadata;
        public TextView tvdeskripsi;


        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata= itemView.findViewById(R.id.IvGambarnovel);
            tvhargadata= itemView.findViewById(R.id.tv_harga);
            tvNamadata= itemView.findViewById(R.id.tv_Nama);
            tvdeskripsi= itemView.findViewById(R.id.tv_deskripsi);

        }
    }
}
