package com.example.novel;

public class menu {
    private String Nama;
    private String Harga;
    private String Gambar;
    private  String Deskripsi;

    public menu(String dataNama, String dataHarga, String dataGambar,String dataDeskripsi){
        Nama = dataNama;
        Harga = dataHarga;
        Gambar = dataGambar;
        Deskripsi=dataDeskripsi;
    }

    public String getNama() {
        return Nama;
    }

    public String getHarga() {
        return Harga;
    }

    public String getGambar() {
        return Gambar;
    }

    public String getDeskripsi() {
        return Deskripsi;
    }
}
